package com.example.midterm_2331024_sec6;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.ArrayList;

public class mainController
{
    @javafx.fxml.FXML
    private TableColumn<PetMonitor, String> lastchekupTableColumn;
    @javafx.fxml.FXML
    private TableView < String>petTableView;
    @javafx.fxml.FXML
    private DatePicker lastchekupDatePicker;
    @javafx.fxml.FXML
    private TableColumn<PetMonitor, String> petidTableColumn;
    @javafx.fxml.FXML
    private TableColumn<PetMonitor, String> pettempTableColumn;
    @javafx.fxml.FXML
    private DatePicker filterDatePicker;
    @javafx.fxml.FXML
    private TextArea notificationTextArea;
    @javafx.fxml.FXML
    private ComboBox  < String>pettypeComboBox;
    @javafx.fxml.FXML
    private TextField petidTextField;
    @javafx.fxml.FXML
    private TableColumn<PetMonitor, String> pettypeTableColumn;
    @javafx.fxml.FXML
    private ComboBox < String> filterComboBox;
    @javafx.fxml.FXML
    private TextField tempincelsiusTextField;
    @javafx.fxml.FXML
    private Label highesttempshowLabel;
    @javafx.fxml.FXML
    private CheckBox vaccinatedCheckBox;
    @javafx.fxml.FXML
    private TableColumn vaccinatedTableColumn;

    @javafx.fxml.FXML
    public void initialize() {
        lastchekupDatePicker.setValue(LocalDate.of(2022,01,01));
        pettypeComboBox.getItems().addAll("Dog", "cat", "bird");
        filterComboBox.getItems().addAll("Dog", "cat", "bird");
        filterDatePicker.setValue(LocalDate.of(2022,01,01));
        //String petId, String petType, float petTempCels,
        // LocalDate lastChekupDate, boolean vaccinated

        petidTableColumn.setCellValueFactory(new PropertyValueFactory<>("petId"));
        pettypeTableColumn.setCellValueFactory(new PropertyValueFactory<>("petType"));
        pettempTableColumn.setCellValueFactory(new PropertyValueFactory<>("petTempCels"));
        lastchekupTableColumn.setCellValueFactory(new PropertyValueFactory<>("lastChekupDate"));
        vaccinatedTableColumn.setCellValueFactory(new PropertyValueFactory<>("vaccinated"));

    }

    ArrayList<PetMonitor> petmonitorlist = new ArrayList<>();

    @javafx.fxml.FXML
    public void highesttempOnAction(ActionEvent actionEvent) {
        ArrayList<PetMonitor> highesttemp = new ArrayList<>();
        float highestemp = petmonitorlist.getFirst().getPetTempCels();
        for (int i = 0; i < petmonitorlist.toArray().length ; i++) {
            if (petmonitorlist.getFirst().getPetTempCels() >= highestemp){
                highestemp = petmonitorlist.getFirst().getPetTempCels();

            }

            highestemp.

        }
    }

    @javafx.fxml.FXML
    public void filterOnAction(ActionEvent actionEvent) {

        String petId = petidTextField.getText();
        String petType = pettypeComboBox.getValue();
        float petTempCels = Float.parseFloat(tempincelsiusTextField.getText());
        LocalDate lastCheckupDate = lastchekupDatePicker.getValue();
        boolean vaccinated = vaccinatedCheckBox.isSelected();



        ArrayList<PetMonitor> filteredpetlist = new ArrayList<>();
        String fpettype = filterComboBox.getValue();
        LocalDate lastchekupdate;
        if (lastchekupdate.isAfter(lastchekupDatePicker)){
            return;
        }
        String fpetType;
        PetMonitor s = new PetMonitor(petId,fpetType,petTempCels,lastCheckupDate,vaccinated);
        filteredpetlist.add(s);
        petTableView.getItems().clear();
        petTableView.getItems().addAll(filteredpetlist);









    }

    @javafx.fxml.FXML
    public void addnewpetOnAction(ActionEvent actionEvent) {


        String petId = petidTextField.getText();
        String petType = pettypeComboBox.getValue();
        float petTempCels = Float.parseFloat(tempincelsiusTextField.getText());
        LocalDate lastCheckupDate = lastchekupDatePicker.getValue();
        boolean vaccinated = vaccinatedCheckBox.isSelected();

        boolean petconsistD = false;
        for (int i = 0; i < petidTextField.getText().length(); i++) {
            if((i >=0) && i<= 9){
                petconsistD = true;
            }
        }
        if ((petconsistD == true) && petTempCels >= 30 || petTempCels <= 45.0){
            PetMonitor s = new PetMonitor(petId,petType,petTempCels,lastCheckupDate,vaccinated);
            petmonitorlist.add(s);
            petTableView.getItems().addAll(String.valueOf(s));
            notificationTextArea.setText("pet added");
        }



    }


}