module com.example.midterm_2331024_sec6 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.midterm_2331024_sec6 to javafx.fxml;
    exports com.example.midterm_2331024_sec6;
}